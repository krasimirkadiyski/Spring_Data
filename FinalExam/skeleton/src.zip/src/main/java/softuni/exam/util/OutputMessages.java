package softuni.exam.util;

public enum OutputMessages {
    ;
    public static final String SUCCESSFULLY_IMPORTED_MECHANIC = "Successfully imported mechanic %s %s";
    public static final String SUCCESSFULLY_IMPORTED_PART = "Successfully imported part %s - %.2f";
    public static final String SUCCESSFULLY_IMPORTED_TASK = "Successfully imported task %.2f";
    public static final String SUCCESSFULLY_IMPORTED_CAR = "Successfully imported car %s - %s";
    public static final String INVALID_MECHANIC ="Invalid mechanic";
    public static final String INVALID_PART ="Invalid part";
    public static final String INVALID_TASK="Invalid task";
    public static final String INVALID_CAR="Invalid car";
}
