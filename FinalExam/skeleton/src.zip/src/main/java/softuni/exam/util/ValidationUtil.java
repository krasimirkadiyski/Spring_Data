package softuni.exam.util;

public interface ValidationUtil {
    <E> boolean validate (E entity);
}
